import Splash from './Splash';
import Home from './Home';
import Register from './Register';
import SHasil from './SHasil';
import SPeserta from './SPeserta';
import SInformasi from './SInformasi';
import SWebsite from './SWebsite';
import SFacebook from './SFacebook';
import SInstagram from './SInstagram';
import SContact from './SContact';















export {
  Splash,
  Home,
  SHasil,
  Register,
  SPeserta,
  SInformasi,
  SWebsite,
  SFacebook,
  SInstagram,
  SContact
};
